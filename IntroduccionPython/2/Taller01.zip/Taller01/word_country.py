import sys

txt = sys.argv[1]
with open(txt ,'r') as file:
   bloque = file.read()
   palabras = set(bloque.split())
   caracteres = set([letter for word in palabras for letter in word])  
print ("=" * len(txt))
print (f'{txt}')
print ("=" * len(txt))
print (f'El Número de caracteres distintos es: {len(caracteres)}') 
print (f'El Número de palabras distintas es: {len(palabras)}\n')
