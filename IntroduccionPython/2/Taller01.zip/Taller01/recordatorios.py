from datetime import datetime

recordatorios = [['2021-01-01', "11:00", "Levantarse y ejercitar"],
 ['2021-05-01', "15:00", "No trabajar"],
 ['2021-07-15', "13:00", "No hacer nada es feriado"],
 ['2021-09-18', "16:00", "Ramadas"],
 ['2021-12-25', "00:00", "Navidad"]]

def error():
    print ("Ingrese valor correcto")
    return

def imprimir():
    actividades.sort()
    for l in actividades: print(l)
    return

def paso1():
    try:
        print("\n1.- Agregar evento: (2021-02-02 a las 06:00 de la mañana para Empezar el año)")
        fecha = input("Ingresa una fecha en formato YYYY-MM-DD -> ")
        datetime.strptime(fecha, '%Y-%m-%d')
        hora = input("Ingresa una hora en formato HH:MM -> " )
        tarea = input("ingrese la tarea -> ")    
        actividades.append([fecha,hora,tarea])
        print("RESULTADO :")
        imprimir()
        
    except ValueError:
        error()
        paso1()
    return

def paso2():
    try:
        print(f'\n2.- Editar evento: {actividades[3]}')
        fecha = input("Corrige la fecha en formato YYYY-MM-DD (2021-07-16)-> ")
        datetime.strptime(fecha, '%Y-%m-%d')
        actividades[3][0] = fecha
        print("RESULTADO :")
        imprimir()

    except ValueError:
        error()
        paso2()
    return

actividades = recordatorios

print("\nRECORDATORIOS")
imprimir()
paso1()
paso2()
print(f'\n3.- Eliminar evento: {actividades[2]}')
temp =input("Pulsa una tecla para continuar...") 
del actividades[2]
print("RESULTADO :")
imprimir()

print(f'\n4.- Se agregar la cena de navidad y año nuevo')
temp =input("Pulsa una tecla para continuar...") 
actividades.append(['2021-12-24','22:00','Cena de Navidad'])
actividades.append(['2021-12-31','22:00','Cena de Año Nuevo'])
print("RESULTADO ORDENADO:")
imprimir()
print(F'RESULTADO RAW:\n{actividades}')