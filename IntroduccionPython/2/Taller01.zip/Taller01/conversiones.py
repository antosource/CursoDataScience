import sys

try:
    pesoChileno     = int(sys.argv[4]) 
    solPeruano      = float(sys.argv[1]) * pesoChileno   
    pesoArgentino   = float(sys.argv[2]) * pesoChileno   
    dolarAmericano  = float(sys.argv[3]) * pesoChileno   

    print(f'Los {pesoChileno} pesos equivalen a : ')
    print(f'{solPeruano} Soles')
    print(f'{pesoArgentino} Pesos Argentinos')
    print(f'{dolarAmericano} Dólares\n')

except Exception :
    print ("Favor ingresar un valor correcto\n")
    